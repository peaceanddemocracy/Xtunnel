#!/bin/sh
cd /xtunnel/
sh stop.sh
sh start.sh

