#!/bin/sh
ulimit -s 65535
ulimit -n 65535
logname=server.log
cd /xtunnel/
nohup java -Xmx1024M -XX:MaxGCPauseMillis=30 -jar xt.jar > $logname 2>&1  &
echo XTunnel is running,log file /xtunnel/$logname

