ps -ef | grep xt.jar | grep -v grep | awk '{print $2}' | xargs kill -s 9

